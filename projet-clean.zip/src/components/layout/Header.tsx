'use client'

import { Search, Menu } from 'lucide-react'
import NotificationBell from './NotificationBell'
import styles from './layout.module.css'
import { usePathname } from 'next/navigation'
import { useSidebar } from './SidebarContext'

interface HeaderProps {
  userName?: string
  userRole?: string
}

const titleMap: Record<string, string> = {
  '/': 'Vue d\'ensemble',
  '/dossiers': 'Répertoire des dossiers',
  '/import': 'Import de dossiers',
  '/users': 'Gestion des utilisateurs',
  '/preferences': 'Préférences'
}

export default function Header({ userName = 'Utilisateur', userRole = 'Membre du Conseil Syndical' }: HeaderProps) {
  const pathname = usePathname()
  const { toggleSidebar } = useSidebar()
  const initials = userName.substring(0, 2).toUpperCase()

  // Find exact match or falls back to generic fallback
  const title = titleMap[pathname] ||
    (pathname.startsWith('/dossiers/') ? 'Détail du dossier' : 'Tableau de bord')

  return (
    <header className={styles.header}>
      <div className={styles.headerLeft}>
        <button className={styles.menuBtn} onClick={toggleSidebar} aria-label="Toggle Menu">
          <Menu size={24} />
        </button>
        <div className={styles.headerTitle}>{title}</div>
      </div>
      <div className={styles.headerRight}>
        <div className={styles.searchBar}>
          <Search size={18} color="var(--text-secondary)" />
          <input type="text" placeholder="Rechercher un dossier..." className={styles.searchInput} />
        </div>

        <NotificationBell />

        <div className={styles.userProfile}>
          <div className={styles.avatar}>{initials}</div>
          <div className={styles.userInfo}>
            <span className={styles.userName}>{userName}</span>
            <span className={styles.userRole}>{userRole}</span>
          </div>
        </div>
      </div>
    </header>
  )
}

